function GetPluginAuthor()
    return "DeadPool (ChatGPT)"
end

function GetPluginVersion()
    return "v1.0.0"
end

function GetPluginName()
    return "Custom Commands"
end

function GetPluginWebsite()
    return "https://github.com/swiftly-solution/custom-commands"
end
